The Dash Framework is the Dependency Acquisition and Structural Hierarchy Framework,
add a bit of component management to your software.



What is it? A pair of Java Annotations (Obtain and Build) that allow components
to declare and lazily obtain acquirable resources.


Some important facets of this include:
1) Components can be hierarchtically composed (via Build) and parent components 
can "offer" resource to be Obtain'ed by child components.

2) A Dash Annotated Field will be assigned a value _once_ in a thread safe manner
and future attempts to re-set the value will exception out.

3) A Dash Annotated Method will be executed _once_ in a thread safe manner and it's 
result stored for all future use.


Why do this? Dependency Injection is all the rage, and very nice, but I wanted 
a declarative approach and hierachtical component trees.


Any inspiration for this? Yes, PEAK. The Python Enterprise Application Kit is an
inspriring collection of code and ideas. This framework derives very closely from 
the PEAK Binding framework. See http://peak.telecommunity.com/



Package contents:
/core:      This contains the central Annotations and Interfaces that define Dash.
/examples:  Various uses and configurations of Dash usage. Supports the test cases.
/aspectj_impl:  The AspectJ implementation of the runtime behavior for Dash.
/aspectj_impl_tests:    Test cases for the aspectj_impl support classes.
/tests:     Various JUnit test cases to excercise the Dash api and runtime.
/performance:   Currently contains a SequentialTiming test to measure access time overhead.


Useful ant targets:
test:       Run JUnits tests
sequential: Run SequentialTiming test and print results.



Runtime requirements:
JDK 1.5 (or 5.0 or whatever I should call it)
AspectJ 1.5

Why AspectJ? I like it and wanted to use it for something interesting. I plan eventually 
to provide an alternate APT implementation to remove barriers but needed to make it
work first.


Criticism and Feedback Welcome,
John D. Heintz