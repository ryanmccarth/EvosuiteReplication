/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import dash.aspectj.annotations.AnnotationHelper;
import dash.aspectj.memberClosures.FieldClosure;
import dash.aspectj.memberClosures.MemberClosure;
import dash.aspectj.memberClosures.MethodClosure;

public class OfferingMapBuilder {
	
	public static Map<Object, MemberClosure> buildOfferedMap(Class forClass) {
		Map<Object, MemberClosure> result = new HashMap<Object, MemberClosure>();
		
		for (Field member : forClass.getDeclaredFields()) {
			for (String key : AnnotationHelper.getOfferedKeys(member)) {
				result.put(key, new FieldClosure(member));
			}
			for (Class cls : AnnotationHelper.getOfferedClasses(member)) {
				result.put(cls, new FieldClosure(member));
			}
		}
		
		for (Method member : forClass.getDeclaredMethods()) {
			for (String key : AnnotationHelper.getOfferedKeys(member)) {
				result.put(key, new MethodClosure(member));
			}
			for (Class cls : AnnotationHelper.getOfferedClasses(member)) {
				result.put(cls, new MethodClosure(member));
			}
		}
				
		return result;
	}

}
