/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj.memberClosures;

import java.lang.reflect.Field;

import dash.ComponentProvider;
import dash.DashException;
import dash.aspectj.annotations.AnnotationHelper;
import dash.aspectj.boundAccessors.BoundAccessor;
import dash.aspectj.boundAccessors.FieldAccessor;

/**
 * @author jheintz
 *
 */
public class FieldClosure implements MemberClosure {

	String name;
	Class declClass;
	Field field;

	public FieldClosure(String name, Class declClass) {
		this.name = name;
		this.declClass = declClass;
	}
	
	public FieldClosure(Field field) {
		this.field = field;
		this.field.setAccessible(true);
		this.name = field.getName();
		this.declClass = field.getDeclaringClass();
	}
	
	public String toString() {
		return "FieldClosure: " + declClass.getCanonicalName() + "." + name;
	}
	
	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#requiresLookup()
	 */
	public boolean requiresLookup() {
		return true;
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#getValue()
	 */
	public Object getValue(ComponentProvider forTarget) {
		return null;
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#createBoundAccessor(dash.ComponentProvider)
	 */
	public BoundAccessor createBoundAccessor(ComponentProvider forTarget) {
		return new FieldAccessor(forTarget, getField());
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#getName()
	 */
	public String getName() {
		return name;
	}

	Field getField() {
		if (field == null) {
			try {
				field = declClass.getDeclaredField(name);
				field.setAccessible(true);
			} catch (NoSuchFieldException ex) {
				throw new DashException(ex);
			}
		}
		
		return field;
	}

	public boolean isBuildAnnotation() {
		return AnnotationHelper.isBuildAnnotation(getField());
	}
}
