/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj;

import dash.ComponentProvider;
import dash.DashException;
import dash.aspectj.boundAccessors.BoundAccessor;
import dash.aspectj.memberClosures.MemberClosure;
import dash.providerFactory.ProviderFactory;

/**
 * @author jheintz
 * 
 */
public class Binding {

	public static BoundAccessor bind(ComponentProvider forTarget,
			MemberClosure memberClosure, boolean setProviderContext) {
		BoundAccessor accessor = getBoundAccessor(forTarget, memberClosure);

//		// check for already set _and_ new value in closure!
//		if (accessor.isBound() && !memberClosure.requiresLookup())
//			throw new BuildException("Can't reset a bound member. At " + memberClosure.toString());

		if (!accessor.isBound()) {
			synchronized (accessor) {
				if (!accessor.isBound()) {

					// now bind accessor (just once)
					bindAccessor(accessor, forTarget, memberClosure, setProviderContext);

				}
			}
		}

		return accessor;
	}

	static void bindAccessor(BoundAccessor accessor,
			ComponentProvider forTarget, MemberClosure memberClosure,
			boolean setProviderContext) {
		Object value = null;

		if (memberClosure.requiresLookup()) {
			Class clazz = accessor.getType();
			String key = accessor.getAnnotationValue();
			value = ProviderFactory.lookup(clazz, key, forTarget);
		} else {
			value = memberClosure.getValue(forTarget);
		}

		if (value == null)
			throw new DashException("Unable to acquire object for "
					+ memberClosure.toString());

		if (setProviderContext)
			trySetProviderContext(forTarget, value);

		accessor.setReference(value);

	}

	/**
	 * @return The returned object must be unique for any set of args.
	 *         Synchronized locking occurs on the AtomicAccessor.
	 */
	public static BoundAccessor getBoundAccessor(ComponentProvider forTarget,
			MemberClosure memberClosure) {
		Object key = generateMapKey(memberClosure);

		BoundAccessor accessor = (BoundAccessor) forTarget.getBindingMap().get(key);

		if (accessor == null) {
			accessor = memberClosure.createBoundAccessor(forTarget);

			BoundAccessor winner = forTarget.getBindingMap().putIfAbsent(key,
					accessor);

			if (winner != null) {
				// some other thread beat us to the punch.
				// use the one from the bindingMap only.
				accessor = winner;
			}
		}

		return accessor;
	}

	public static void trySetProviderContext(ComponentProvider context,
			Object onValue) {
		if (onValue instanceof ComponentProvider) {
			ComponentProvider comp = (ComponentProvider) onValue;

			if (comp.getProviderContext() != null)
				throw new DashException("Provider Context Already set for "
						+ comp);

			comp.setProviderContext(context);
		}
	}

	public static Object generateMapKey(MemberClosure memberClosure) {
		return memberClosure.getName();
	}
}
