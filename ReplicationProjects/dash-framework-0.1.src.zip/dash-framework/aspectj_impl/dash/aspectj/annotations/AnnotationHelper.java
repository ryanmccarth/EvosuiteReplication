/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj.annotations;

import java.lang.reflect.AccessibleObject;

import dash.Build;
import dash.Obtain;

public abstract class AnnotationHelper {

	private static final String[] EMPTY_KEYS = new String[] {};
	private static final Class[] EMPTY_CLASSES = new Class[] {};

	public static String[] getOfferedKeys(AccessibleObject object) {
		
		if (object.isAnnotationPresent(Build.class)) {
			return object.getAnnotation(Build.class).offerAsKey();
		} else if (object.isAnnotationPresent(Obtain.class)) {
			return object.getAnnotation(Obtain.class).offerAsKey();			
		} else {
			return EMPTY_KEYS;
		}
	}
	
	public static Class[] getOfferedClasses(AccessibleObject object) {
		
		if (object.isAnnotationPresent(Build.class)) {
			return object.getAnnotation(Build.class).offerAs();
		} else if (object.isAnnotationPresent(Obtain.class)) {
			return object.getAnnotation(Obtain.class).offerAs();			
		} else {
			return EMPTY_CLASSES;
		}
	}
	
	public static String getValue(AccessibleObject object) {
		if (object.isAnnotationPresent(Build.class)) {
			return object.getAnnotation(Build.class).value();
		} else if (object.isAnnotationPresent(Obtain.class)) {
			return object.getAnnotation(Obtain.class).value();			
		} else {
			return "";
		}
		
	}

	public static boolean isBuildAnnotation(AccessibleObject object) {
		return object.isAnnotationPresent(Build.class);
	}

}
