/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj.memberClosures;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import dash.ComponentProvider;
import dash.DashException;
import dash.aspectj.annotations.AnnotationHelper;
import dash.aspectj.boundAccessors.BoundAccessor;
import dash.aspectj.boundAccessors.MethodAccessor;

/**
 * @author jheintz
 *
 */
public class MethodClosure implements MemberClosure {

	String name;
	Class declClass;
	Method method;

	public MethodClosure(String name, Class declClass) {
		this.name = name;
		this.declClass = declClass;
	}
	
	public MethodClosure(Method method) {
		this.method = method;
		this.method.setAccessible(true);
		this.name = method.getName();
		this.declClass = method.getDeclaringClass();
	}
	
	public String toString() {
		return "FieldClosure: " + declClass.getCanonicalName() + "." + name;
	}
	
	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#requiresLookup()
	 */
	public boolean requiresLookup() {
		return false;
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#getValue()
	 */
	public Object getValue(ComponentProvider forTarget) {
		return getReflectedValue(forTarget);
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#getValue()
	 */
	public Object getReflectedValue(ComponentProvider forTarget) {
		try {
			return getMethod().invoke(forTarget, new Object[] {});
		} catch (IllegalArgumentException e) {
			throw new DashException(e);
		} catch (IllegalAccessException e) {
			throw new DashException(e);
		} catch (InvocationTargetException e) {
			throw new DashException(e);
		}
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#createBoundAccessor(dash.ComponentProvider)
	 */
	public BoundAccessor createBoundAccessor(ComponentProvider forTarget) {
		return new MethodAccessor(forTarget, getMethod());
	}

	/**
	 * @see dash.aspectj.memberClosures.MemberClosure#getName()
	 */
	public String getName() {
		return name;
	}

	Method getMethod() {
		if (method == null) {
			try {
				method = declClass.getDeclaredMethod(name, new Class[] {});
				method.setAccessible(true);
			} catch (NoSuchMethodException ex) {
				throw new DashException(ex);
			}
		}
		
		return method;
	}

	public boolean isBuildAnnotation() {
		return AnnotationHelper.isBuildAnnotation(getMethod());
	}
}
