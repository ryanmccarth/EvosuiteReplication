/*
* Copyright (C) 2005  John D. Heintz
* 
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Library General Public License
* as published by the Free Software Foundation; either version 2.1
* of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Library General Public License for more details.
*
* John D. Heintz can be reached at: jheintz@pobox.com 
*/
package dash.aspectj.boundAccessors;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicBoolean;

import dash.DashException;
import dash.aspectj.annotations.AnnotationHelper;

/**
 * @author jheintz
 *
 */
public class FieldAccessor implements BoundAccessor {
	AtomicBoolean atomicBool = new AtomicBoolean(false);
	Object forTarget;
	Field field;
	AnnotationHelper annotHelper;
	
	public FieldAccessor(Object forTarget, Field field) {
		this.forTarget = forTarget;
		this.field = field;
	}

	/**
	 * @see dash.aspectj.boundAccessors.BoundAccessor#isBound()
	 */
	public boolean isBound() {
		return atomicBool.get();
	}

	/**
	 * @see dash.aspectj.boundAccessors.BoundAccessor#getType()
	 */
	public Class getType() {
		return this.field.getType();
	}

	/**
	 * @see dash.aspectj.boundAccessors.BoundAccessor#getAnnotationValue()
	 */
	public String getAnnotationValue() {
		return AnnotationHelper.getValue(field);
	}

	/**
	 * @see dash.aspectj.boundAccessors.BoundAccessor#setReference(java.lang.Object)
	 */
	public void setReference(Object value) {
		try {
			this.field.set(forTarget, value);
		} catch (IllegalArgumentException e) {
			throw new DashException(e);
		} catch (IllegalAccessException e) {
			throw new DashException(e);
		}
		
		if (! this.atomicBool.compareAndSet(false, true)) {
			throw new IllegalStateException("Ack! Can't fail this call!");
		}
	}

	public Object getReference() {
		try {
			return this.field.get(forTarget);
		} catch (IllegalArgumentException e) {
			throw new DashException(e);
		} catch (IllegalAccessException e) {
			throw new DashException(e);
		}
	}

}
